def lambda_handler(event, context):
    return {"status": "ok"}
